
  # Website Replica with Animations

  This is a code bundle for Website Replica with Animations. The original project is available at https://www.figma.com/design/WTkLj7oBabapkLZfO8dQwM/Website-Replica-with-Animations.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  